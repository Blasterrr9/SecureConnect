package com.example.ciscog

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import com.github.tehras.charts.piechart.PieChart
import com.github.tehras.charts.piechart.PieChartData
import com.github.tehras.charts.piechart.renderer.SimpleSliceDrawer
import java.io.File
import java.io.FileOutputStream

class ReportePlantilla5 : AppCompatActivity() {
    private var btnRegresar: ImageButton? = null
    private var btnDescarga: ImageButton? = null
    private var textAtributo1: TextView? = null
    private var textAtributo2: TextView? = null
    private var textAtributo3: TextView? = null
    private var textAtributo4: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reporte_plantilla_5)

        val bundle = intent.extras
        val email = bundle?.getString("email")

        init()
        listeners(email.toString())
    }

    private fun init() {
        btnRegresar = findViewById(R.id.return_btn)
        btnDescarga = findViewById(R.id.descarga_btn)
        textAtributo1 = findViewById(R.id.enrutamiento_text)
        textAtributo2 = findViewById(R.id.eigrp_text)
        textAtributo3 = findViewById(R.id.ospf_text)
        textAtributo4 = findViewById(R.id.rutas_text)

        // Obtener los datos del intent
        val atributo1 = intent.getStringExtra("atributo1_valor")
        val atributo2 = intent.getStringExtra("atributo2_valor")
        val atributo3 = intent.getStringExtra("atributo3_valor")
        val atributo4 = intent.getStringExtra("atributo4_valor")

        // Mostrar los datos en los TextViews
        textAtributo1?.text = atributo1
        textAtributo2?.text = atributo2
        textAtributo3?.text = atributo3
        textAtributo4?.text = atributo4

        val data = atributo1?.let { parseData(it) }

        // Actualizar configuraciones por tipo
        updateTextViews(this, data!!, typeMappings)

        // Configurar el gráfico
        val composeView = findViewById<ComposeView>(R.id.grafico_compose)
        composeView.setContent {
            Pastel(data)
        }
    }

    val typeMappings = mapOf(
        "EIGRP" to R.id.eigrp_grafico,
        "OSPF" to R.id.ospf_grafico,
        "RUTAS" to R.id.rutas_grafico,
    )

    fun updateTextViews(context: Context, data: List<Triple<String, Float, String>>, // Datos procesados: nombre, valor, porcentaje
                        mappings: Map<String, Int>) // Mapeo del nombre con los IDs de los TextView
    {
        // Crear un mapa de datos para facilitar la búsqueda
        val dataMap = data.associate { it.first to it }

        // Iterar sobre los mappings y actualizar los TextView correspondientes
        mappings.forEach { (key, textViewId) ->
            val textView = (context as Activity).findViewById<TextView>(textViewId)
            val value = dataMap[key]?.second ?: 0f
            val percentage = dataMap[key]?.third ?: "0%"

            // Formatear el texto para el TextView
            val formattedText = "$key\n($percentage)"
            textView.text = formattedText
        }
    }


    private fun listeners(email: String) {
        // Listener para el botón de regresar, que regresa a la actividad anterior
        btnRegresar?.setOnClickListener {
            val intent = Intent(this, ListaReporteReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
            finish()// Finaliza la actividad actual para evitar volver a ella con el botón de retroceso
        }

        // Listener para el botón de descarga, que muestra un mensaje de descarga
        btnDescarga?.setOnClickListener {
            val fileName = "ReporteTipo5_${System.currentTimeMillis()}.pdf"
            val pdfPath = generatePdfFromActivity(fileName)
            if (pdfPath != null) {
                Toast.makeText(this, "Reporte descargado: $pdfPath", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al descargar el reporte", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun generatePdfFromActivity(fileName: String): String? {
        return try {
            // Capturar la vista raíz del Activity
            val rootView = window.decorView.rootView
            rootView.isDrawingCacheEnabled = true
            val bitmap = Bitmap.createBitmap(rootView.drawingCache)
            rootView.isDrawingCacheEnabled = false

            // Crear el archivo PDF
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawBitmap(bitmap, 0f, 0f, null)
            pdfDocument.finishPage(page)

            // Obtener la ruta para guardar en Descargas
            val backupPath = File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)

            // Guardar el PDF en el archivo
            val outputStream = FileOutputStream(backupPath)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.close()

            // Devolver la ruta del archivo PDF
            backupPath.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }


    fun parseData(input: String): List<Triple<String, Float, String>> {
        // Divide las entradas y procesa cada una
        return input.split(" - ").map { item ->
            val parts = item.split(": ")
            val name = parts[0]
            val value = parts[1].substringBefore(" (").toFloat() // Número de configuraciones
            val percentage = parts[1].substringAfter(" (").removeSuffix(")") // Porcentaje
            Triple(name, value, percentage)
        }
    }


    @Composable
    fun Pastel(data: List<Triple<String, Float, String>>) {
        val usedColors = mutableSetOf<Color>() // Mantén un registro de colores usados en la UI

        // Lista de colores directamente como objetos Color
        val colorList = listOf(
            Color(0xFF0EA982), // chat_green
            Color(0xFF2292D1), // cyan
            Color(0xFF098F33), // green
            Color(0xFFD3EFFF), // light_blue
            Color(0xFF3CE671), // light_green
            Color(0xFF505050), // gray
            Color(0xFFFF0000), // red
            Color(0xFFFF3030)  // light_red
        )

        // Si no hay datos, no renderizar el gráfico
        if (data.isEmpty()) return



        // Generar las porciones del gráfico
        val slices = data.map { (label, value) ->
            // Obtener un color único de la lista
            val color = generateUniqueComposeColor(colorList, usedColors)
            PieChartData.Slice(value = value, color = color)
        }

        // Crear el gráfico de pastel
        PieChart(
            pieChartData = PieChartData(slices = slices),
            sliceDrawer = SimpleSliceDrawer(sliceThickness = 100f)
        )
    }

    // Función para obtener un color único en Compose
    private fun generateUniqueComposeColor(
        colorList: List<Color>,
        usedColors: MutableSet<Color>
    ): Color {
        // Si todos los colores fueron usados, reiniciar
        if (usedColors.size == colorList.size) {
            usedColors.clear()
        }

        // Filtrar colores no utilizados
        val availableColors = colorList.filter { it !in usedColors }

        // Seleccionar un color no utilizado
        val selectedColor = availableColors.random()

        // Marcar como usado
        usedColors.add(selectedColor)

        return selectedColor
    }


}
