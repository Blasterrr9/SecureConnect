package com.example.ciscog

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageButton
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.MultiFactorInfo
import com.google.firebase.auth.MultiFactorSession
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.PhoneMultiFactorGenerator
import java.util.concurrent.TimeUnit

class AdminActivity : AppCompatActivity() {
    private var btnRutasEst: Button? = null
    private var btnNat: Button? = null
    private var btnEigrp: Button? = null
    private var btnOspf: Button? = null
    private var btnVlan: Button? = null
    private var btnStp: Button? = null
    private var btnAcl: Button? = null
    private var btnUsuario: Button? = null
    private var btnConfiguracion: Button? = null
    private var btnReporte: Button? = null
    private var btnResp: Button? = null
    private var btnRespNube: AppCompatImageButton? = null

    private var btnAutenticacion: AppCompatImageButton? = null
    private var btnCerrarSesion: Button? = null
    private var tvNombreUsuario: TextView? = null
    private var tvCorreoUsuario: TextView? = null

    private lateinit var auth: FirebaseAuth
    private lateinit var verificationId: String
    private var forceResendingToken: PhoneAuthProvider.ForceResendingToken? = null
    private lateinit var multiFactorSession: MultiFactorSession

    private lateinit var phone: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.admin)

        auth = FirebaseAuth.getInstance()

        val email = intent.getStringExtra("email")
        val nombre = intent.getStringExtra("nombre")
        val apellido = intent.getStringExtra("apellido")

        init(email.toString(), nombre.toString(), apellido.toString())
        listeners(email.toString(), nombre.toString(), apellido.toString())

    }

    private fun init(email: String, nombre: String, apellido: String) {
        btnNat = findViewById(R.id.btnNat)
        btnRutasEst = findViewById(R.id.btnRutasEst)
        btnEigrp = findViewById(R.id.btnEigrp)
        btnOspf = findViewById(R.id.btnOspf)
        btnVlan = findViewById(R.id.btnVlans)
        btnStp = findViewById(R.id.btnStp)
        btnAcl = findViewById(R.id.btnAcls)
        btnUsuario = findViewById(R.id.btnUsuarios)
        btnConfiguracion = findViewById(R.id.btnConfiguracion)
        btnReporte = findViewById(R.id.btn_reportes)
        btnResp = findViewById(R.id.btn_respaldo)
        btnRespNube = findViewById(R.id.btnRespaldoNube)

        btnAutenticacion = findViewById(R.id.btnMFA)
        btnCerrarSesion = findViewById(R.id.cerrarSesion)
        tvCorreoUsuario = findViewById(R.id.correo_usuario)
        tvCorreoUsuario?.text = email
        tvNombreUsuario = findViewById(R.id.nombre_usuario)
        val nombreCompleto = "$nombre $apellido"
        tvNombreUsuario?.text = nombreCompleto
    }

    private fun listeners(email: String, nombre: String, apellido: String) {
        btnRutasEst?.setOnClickListener {
            val intent = Intent(this, ListaRutasEstReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnCerrarSesion?.setOnClickListener {
            auth.signOut()
            Toast.makeText(baseContext, "Logout Successful", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnNat?.setOnClickListener {
            val intent = Intent(this, ListaNatReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnEigrp?.setOnClickListener {
            val intent = Intent(this, ListaEigrpReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnOspf?.setOnClickListener {
            val intent = Intent(this, ListaOspfReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnVlan?.setOnClickListener {
            val intent = Intent(this, ListaVlanReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnStp?.setOnClickListener {
            val intent = Intent(this, ListaStpReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnAcl?.setOnClickListener {
            val intent = Intent(this, ListaAclReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnConfiguracion?.setOnClickListener {
            val intent = Intent(this, ListaConfig::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnUsuario?.setOnClickListener {
            val intent = Intent(this, ListaUsuarioReg::class.java).apply {
                putExtra("email", email)
                putExtra("nombre", nombre)
                putExtra("apellido", apellido)
            }
            startActivity(intent)
            finish()// Finaliza la actividad actual para evitar volver a ella con el botón de retroceso
        }

        btnReporte?.setOnClickListener {
            val intent = Intent(this, ListaReporteReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnResp?.setOnClickListener {
            val intent = Intent(this, RespaldoLocal::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnRespNube?.setOnClickListener {
            val intent = Intent(this, RespaldoNube::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
        }

        btnAutenticacion?.setOnClickListener {
            // Obtiene el usuario actual
            val user = auth.currentUser
            if (user != null) {
                // Verifica si el usuario tiene MFA habilitado
                val enrolledFactors = user.multiFactor.enrolledFactors
                if (enrolledFactors.isNotEmpty()) {
                    // El usuario tiene MFA habilitado, muestra el diálogo de gestión de MFA
                    showMfaManagementDialog(user, enrolledFactors[0])
                } else {
                    // El usuario no tiene MFA habilitado, muestra el diálogo de registro de MFA pero primero le pide que verifique su correo

                    if (user.isEmailVerified) {
                        showEnrollMfaDialog(user)
                    } else {
                        Toast.makeText(this, "Please, verify your email first.", Toast.LENGTH_SHORT).show()
                        user.sendEmailVerification().addOnCompleteListener { sendTask ->
                            if (sendTask.isSuccessful) {
                                Toast.makeText(this, "Verification email sent to ${user.email}", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Failed to send verification email.", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            } else {
                Toast.makeText(this, "There is no user logged in.", Toast.LENGTH_SHORT).show()
            }
        }

    }

    // Funcion para mostrar el diálogo de gestión de MFA (Desactivar MFA)
    private fun showMfaManagementDialog(user: FirebaseUser, phoneFactor: MultiFactorInfo) {

        
        AlertDialog.Builder(this)
            .setTitle("MFA Authentication")
            .setIcon(R.drawable.identificacion)
            .setMessage("Multi-factor authentication is already enabled. What would you like to do?")

            .setPositiveButton("Change Phone Number") { dialog, _ ->
                // Desenrollar el factor actual y reenrollar con un nuevo número de teléfono

                AlertDialog.Builder(this)
                    .setTitle("Delete")
                    .setIcon(R.drawable.ic_warning)
                    .setMessage("Are you sure you want to change your phone number?")
                    .setPositiveButton("Yes"){ dialog,_->

                        user.multiFactor.unenroll(phoneFactor)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    if (user.isEmailVerified) {
                                        showEnrollMfaDialog(user)
                                    } else {
                                        Toast.makeText(this, "Please, verify your email first.", Toast.LENGTH_SHORT).show()
                                        user.sendEmailVerification().addOnCompleteListener { sendTask ->
                                            if (sendTask.isSuccessful) {
                                                Toast.makeText(this, "Verification email sent to ${user.email}", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(this, "Failed to send verification email.", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                } else {
                                    Toast.makeText(this, "Failed to change phone number.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        dialog.dismiss()

                    }.setNegativeButton("No"){ dialog,_->
                        Toast.makeText(this, "Phone number change canceled", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                    }
                    .create()
                    .show()
            }

            .setNegativeButton("Deactivate") { dialog, _ ->
                // Desenrollar el factor MFA
                AlertDialog.Builder(this)
                    .setTitle("Delete")
                    .setIcon(R.drawable.ic_warning)
                    .setMessage("Are you sure you want to deactivate MFA?")
                    .setPositiveButton("Yes"){ dialog,_->
                        user.multiFactor.unenroll(phoneFactor)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    Toast.makeText(this, "MFA successfully deactivated.", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(this, "Failed to deactivate MFA.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        dialog.dismiss()
                    }.setNegativeButton("No"){ dialog,_->
                        Toast.makeText(this, "MFA deactivation canceled", Toast.LENGTH_SHORT).show()
                        dialog.dismiss()
                    }
                    .create()
                    .show()
            }
            .setNeutralButton("Dismiss") { dialog, _ ->
                dialog.dismiss()
            }

            .create()
            .show()
    }

    // Funcion para mostrar el diálogo de registro de MFA
    private fun showEnrollMfaDialog(user: FirebaseUser) {
        val v = LayoutInflater.from(this).inflate(R.layout.edit_phone_dialog, null)

        val textViewEmailDialog: TextView = v.findViewById(R.id.textview_email_dialog)
        val editTextPhoneDialog: EditText = v.findViewById(R.id.edittext_phone_dialog)

        textViewEmailDialog.text = user.email

        AlertDialog.Builder(this)
            .setView(v)
            .setPositiveButton("Activate") { dialog, _ ->
                val phoneNumber = "+" + editTextPhoneDialog.text.toString()
                if (phoneNumber.isNotEmpty()) {
                    phone = phoneNumber
                    startMfaEnrollment(user, phoneNumber)
                } else {
                    Toast.makeText(this, "Please, enter a valid phone number.", Toast.LENGTH_SHORT).show()
                }
                dialog.dismiss()
            }
            .setNegativeButton("Dismiss") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }

    // Funcion para iniciar el proceso de registro de MFA
    private fun startMfaEnrollment(user: FirebaseUser, phoneNumber: String) {
        user.multiFactor.session
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    multiFactorSession = task.result

                    val options = PhoneAuthOptions.newBuilder(auth)
                        .setPhoneNumber(phoneNumber)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setMultiFactorSession(multiFactorSession)
                        .setCallbacks(callbacks)
                        .build()

                    PhoneAuthProvider.verifyPhoneNumber(options)
                } else {
                    Toast.makeText(this, "Failed to start MFA enrollment.", Toast.LENGTH_SHORT).show()
                }
            }
    }

    // PhoneAuthProvider callbacks
    private val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            // Verificación automática o completada
            enrollMfa(credential)
        }

        override fun onVerificationFailed(e: FirebaseException) {
            if (e is FirebaseAuthInvalidCredentialsException) {
                Toast.makeText(this@AdminActivity, "Invalid request", Toast.LENGTH_SHORT).show()
            } else if (e is FirebaseTooManyRequestsException) {
                Toast.makeText(this@AdminActivity, "Request limit exceeded", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this@AdminActivity, "Verification failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }

        override fun onCodeSent(
            verificationId: String,
            token: PhoneAuthProvider.ForceResendingToken
        ) {
            this@AdminActivity.verificationId = verificationId
            this@AdminActivity.forceResendingToken = token
            showVerificationCodeDialog()
        }
    }

    // Function to show dialog to enter verification code
    @SuppressLint("MissingInflatedId")
    private fun showVerificationCodeDialog() {
        val v = LayoutInflater.from(this).inflate(R.layout.verify_phone_dialog, null)

        val textViewPhoneDialog: TextView = v.findViewById(R.id.textview_phone_dialog)
        val editTextPhoneDialog: EditText = v.findViewById(R.id.edittext_phone_dialog)

        textViewPhoneDialog.text = phone

        AlertDialog.Builder(this)
            .setView(v)
            .setPositiveButton("Verificate") {dialog, _ ->
            val code = editTextPhoneDialog.text.toString()
            if (code.isNotEmpty()) {
                val credential = PhoneAuthProvider.getCredential(verificationId, code)
                enrollMfa(credential)
            } else {
                Toast.makeText(this, "Input the verification code.", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }

        .setNegativeButton("Dismiss") { dialog, _ ->
            dialog.dismiss()
        }

        .show()
    }

    // Function to enroll MFA
    private fun enrollMfa(credential: PhoneAuthCredential) {
        val multiFactorAssertion = PhoneMultiFactorGenerator.getAssertion(credential)
        val user = auth.currentUser

        user?.multiFactor?.enroll(multiFactorAssertion, "Phone Number")
            ?.addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(this, "MFA successfully activated.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Failed to activate MFA.", Toast.LENGTH_SHORT).show()
                }
            }
    }

}
