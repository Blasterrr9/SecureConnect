package com.example.ciscog

import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import com.example.ciscog.adapters.MessageAdapter
import com.example.ciscog.models.Message
import android.os.Handler
import android.os.Looper

class ChatActivity1 : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: ImageButton
    private lateinit var returnButton: ImageButton
    private lateinit var messageList: MutableList<Message>
    private lateinit var messageAdapter: MessageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        messageList = mutableListOf()

        recyclerView = findViewById(R.id.recycler_view)
        messageEditText = findViewById(R.id.message_edit_text)
        sendButton = findViewById(R.id.send_btn)

        // setup recycler view
        messageAdapter = MessageAdapter(messageList)
        recyclerView.adapter = messageAdapter
        val llm = LinearLayoutManager(this)
        llm.stackFromEnd = true
        recyclerView.layoutManager = llm

        returnButton = findViewById(R.id.return_btn)
        returnButton.setOnClickListener {
            finish()
        }

        // Obtener el intent y agregar el primer mensaje
        val config_info = intent.getStringExtra("config_info")
        if (!config_info.isNullOrEmpty()) {
            addToChat(config_info, Message.SENT_BY_ME)
            providePredefinedResponse(1)
        }

        sendButton.setOnClickListener {
            val question = messageEditText.text.toString().trim()

            if (question.isNotEmpty()) {
                addToChat(question, Message.SENT_BY_ME)
                messageEditText.setText("")
                providePredefinedResponse(2)
            } else {
                addToChat("Por favor, escribe una pregunta", Message.SENT_BY_BOT)
            }
        }
    }

    private fun addToChat(message: String, sentBy: String) {
        runOnUiThread {
            messageList.add(Message(message, sentBy))
            messageAdapter.notifyDataSetChanged()
            recyclerView.smoothScrollToPosition(messageAdapter.itemCount)
        }
    }



    private fun providePredefinedResponse(step: Int) {
        val typingMessage = "Typing..."
        addToChat(typingMessage, Message.SENT_BY_BOT)

        // Usamos un Handler para retrasar la ejecución
        Handler(Looper.getMainLooper()).postDelayed({
            // Elimina el mensaje de "Typing..."
            messageList.removeAt(messageList.size - 1)
            messageAdapter.notifyDataSetChanged()

            // Genera la respuesta real
            val response = when (step) {
                1 -> "La configuración indica que el dispositivo R03 está participando en el protocolo de enrutamiento OSPF dentro del área 30, la red anunciada es 192.168.10.128/25 y con la Wildcard 0.0.0.127, con los primeros 25 bits de dirección fijos, permite direcciones desde 192.168.10.128 hasta 192.168.10.255 para que los dispositivos participen en el proceso de OSPF."
                2 -> "La principal diferencia es que OSPF es un protocolo de enrutamiento de estado de enlace, estándar abierto, que utiliza una topología completa para calcular rutas óptimas, mientras que EIGRP es un protocolo de enrutamiento vector distancia avanzado, propietario de Cisco, que utiliza un algoritmo más rápido (DUAL) y es más sencillo de configurar en redes pequeñas o medianas."
                else -> "No tengo una respuesta predefinida para este paso."
            }
            // Agrega la respuesta al chat
            addToChat(response, Message.SENT_BY_BOT)
        }, 4000) // Retraso de 4 segundos
    }
}
