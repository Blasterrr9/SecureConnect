package com.example.ciscog

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import com.github.tehras.charts.piechart.PieChart
import com.github.tehras.charts.piechart.PieChartData
import com.github.tehras.charts.piechart.renderer.SimpleSliceDrawer
import java.io.File
import java.io.FileOutputStream

class ReportePlantilla6 : AppCompatActivity() {
    private var btnRegresar: ImageButton? = null
    private var btnDescarga: ImageButton? = null
    private var textAtributo1: TextView? = null
    private var textAtributo2: TextView? = null
    private var textAtributo3: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reporte_plantilla_6)

        val bundle = intent.extras
        val email = bundle?.getString("email")

        init()
        listeners(email.toString())
    }

    private fun init() {
        btnRegresar = findViewById(R.id.return_btn)
        btnDescarga = findViewById(R.id.descarga_btn)
        textAtributo1 = findViewById(R.id.listas_text)
        textAtributo2 = findViewById(R.id.distribucion_text)

        // Obtener los datos del intent
        val atributo1 = intent.getStringExtra("atributo1_valor")
        val atributo2 = intent.getStringExtra("atributo2_valor")

        // Mostrar los datos en los TextViews
        textAtributo1?.text = atributo1
        textAtributo2?.text = atributo2

        val dataTipo = atributo1?.let { parseData(it) }
        val dataDispositivo = atributo2?.let { parseData(it) }

        // Actualizar listas por tipo
        updateTextViews(this, dataTipo!!, typeMappings)

        // Actualizar listas por dispositivo
        updateTextViews(this, dataDispositivo!!, deviceMappings)

        // Graficar las configuraciones por tipo
        val composeViewTipo = findViewById<ComposeView>(R.id.grafico_compose_tipo)
        composeViewTipo.setContent {
            Pastel(dataTipo)
        }

        // Graficar las configuraciones por dispositivo
        val composeViewDispositivo = findViewById<ComposeView>(R.id.grafico_compose_dispositivo)
        composeViewDispositivo.setContent {
            Pastel(dataDispositivo)
        }
    }

    private fun listeners(email: String) {
        // Listener para el botón de regresar
        btnRegresar?.setOnClickListener {
            val intent = Intent(this, ListaReporteReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
            finish()
        }

        // Listener para el botón de descarga
        btnDescarga?.setOnClickListener {
            val fileName = "ReporteTipo6_${System.currentTimeMillis()}.pdf"
            val pdfPath = generatePdfFromActivity(fileName)
            if (pdfPath != null) {
                Toast.makeText(this, "Reporte descargado: $pdfPath", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al descargar el reporte", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun generatePdfFromActivity(fileName: String): String? {
        return try {
            // Capturar la vista raíz del Activity
            val rootView = window.decorView.rootView
            rootView.isDrawingCacheEnabled = true
            val bitmap = Bitmap.createBitmap(rootView.drawingCache)
            rootView.isDrawingCacheEnabled = false

            // Crear el archivo PDF
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawBitmap(bitmap, 0f, 0f, null)
            pdfDocument.finishPage(page)

            // Obtener la ruta para guardar en Descargas
            val backupPath = File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)

            // Guardar el PDF en el archivo
            val outputStream = FileOutputStream(backupPath)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.close()

            // Devolver la ruta del archivo PDF
            backupPath.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    val typeMappings = mapOf(
        "Estándar" to R.id.estandar_grafico,
        "Extendida" to R.id.extendidas_grafico
    )

    val deviceMappings = mapOf(
        "R01" to R.id.r01_grafico,
        "R02" to R.id.r02_grafico,
        "R03" to R.id.r03_grafico
    )

    fun updateTextViews(context: Context, data: List<Triple<String, Float, String>>, // Datos procesados: nombre, valor, porcentaje
        mappings: Map<String, Int>) // Mapeo del nombre con los IDs de los TextView
    {
        // Crear un mapa de datos para facilitar la búsqueda
        val dataMap = data.associate { it.first to it }

        // Iterar sobre los mappings y actualizar los TextView correspondientes
        mappings.forEach { (key, textViewId) ->
            val textView = (context as Activity).findViewById<TextView>(textViewId)
            val value = dataMap[key]?.second ?: 0f
            val percentage = dataMap[key]?.third ?: "0%"

            // Formatear el texto para el TextView
            val formattedText = "$key\n($percentage)"
            textView.text = formattedText
        }
    }



    fun parseData(input: String): List<Triple<String, Float, String>> {
        return input.split(" - ").map { item ->
            val parts = item.split(": ")
            val name = parts[0]
            val value = parts[1].substringBefore(" (").toFloat() // Número de configuraciones
            val percentage = parts[1].substringAfter(" (").removeSuffix("%)") // Porcentaje sin "%"
            Triple(name, value, "$percentage%")
        }
    }

    @Composable
    fun Pastel(data: List<Triple<String, Float, String>>) {
        val usedColors = mutableSetOf<Color>()

        // Lista de colores para los gráficos
        val colorList = listOf(
            Color(0xFF0EA982), // Verde
            Color(0xFF2292D1), // Azul
            Color(0xFF098F33), // Verde oscuro
            Color(0xFFD3EFFF), // Azul claro
            Color(0xFF3CE671), // Verde claro
            Color(0xFFFFA500), // Naranja
            Color(0xFFFF3030), // Rojo claro
            Color(0xFF505050)  // Gris
        )

        val slices = data.map { (name, value) ->
            val color = generateUniqueComposeColor(colorList, usedColors)
            PieChartData.Slice(value = value, color = color)
        }

        // Crear el gráfico de pastel
        PieChart(
            pieChartData = PieChartData(slices = slices),
            sliceDrawer = SimpleSliceDrawer(sliceThickness = 100f)
        )
    }

    // Generar un color único para cada sección
    private fun generateUniqueComposeColor(
        colorList: List<Color>,
        usedColors: MutableSet<Color>
    ): Color {
        if (usedColors.size == colorList.size) usedColors.clear()
        val availableColors = colorList.filter { it !in usedColors }
        val selectedColor = availableColors.random()
        usedColors.add(selectedColor)
        return selectedColor
    }
}
