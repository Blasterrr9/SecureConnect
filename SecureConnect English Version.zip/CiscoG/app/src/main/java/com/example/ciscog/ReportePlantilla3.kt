package com.example.ciscog

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatImageButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ComposeView
import com.github.tehras.charts.piechart.PieChart
import com.github.tehras.charts.piechart.PieChartData
import com.github.tehras.charts.piechart.renderer.SimpleSliceDrawer
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.MultiFactorInfo
import com.google.firebase.auth.MultiFactorSession
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.PhoneMultiFactorGenerator
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class ReportePlantilla3 : AppCompatActivity() {
    private var btnRegresar: ImageButton? = null
    private var btnDescarga: ImageButton? = null
    private var textAtributo1: TextView? = null
    private var textAtributo2: TextView? = null
    private var textAtributo3: TextView? = null
    private var textAtributo4: TextView? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reporte_plantilla_3)

        val bundle = intent.extras
        val email = bundle?.getString("email")

        init()
        listeners(email.toString())
    }

    private fun init() {
        btnRegresar= findViewById(R.id.return_btn)
        btnDescarga = findViewById(R.id.descarga_btn)
        textAtributo1 = findViewById(R.id.usuario1_text)
        textAtributo2 = findViewById(R.id.configuraciones1_text)
        textAtributo3 = findViewById(R.id.usuario2_text)
        textAtributo4 = findViewById(R.id.configuraciones2_text)

        // Obtener los datos del intent
        val atributo1 = intent.getStringExtra("atributo1_valor")
        val atributo2 = intent.getStringExtra("atributo2_valor")
        val atributo3 = intent.getStringExtra("atributo3_valor")
        val atributo4 = intent.getStringExtra("atributo4_valor")

        // Mostrar los datos en los TextViews
        textAtributo1?.text = "USUARIO 1: $atributo1"
        textAtributo2?.text = atributo2
        textAtributo3?.text = "USUARIO 2: $atributo3"
        textAtributo4?.text = atributo4

        // Parsear datos
        val data = listOf(
            Pair(atributo1 ?: "Usuario 1", sumarConfiguraciones(atributo2)),
            Pair(atributo3 ?: "Usuario 2", sumarConfiguraciones(atributo4))
        )

        // Actualizar los TextViews con los valores correspondientes
        updateTextViews(data)

        // Configurar el gráfico
        val composeView = findViewById<ComposeView>(R.id.grafico_compose)
        composeView.setContent {
            Pastel(data)
        }

    }

    private fun updateTextViews(data: List<Pair<String, Float>>) {
        // Buscar los TextViews específicos para usuario1 y usuario2
        val usuario1Grafico = findViewById<TextView>(R.id.usuario1_grafico)
        val usuario2Grafico = findViewById<TextView>(R.id.usuario2_grafico)

        // Extraer datos
        val (usuario1Nombre, usuario1Total) = data[0]
        val (usuario2Nombre, usuario2Total) = data[1]

        // Calcular el porcentaje total
        val totalConfiguraciones = usuario1Total + usuario2Total
        val usuario1Porcentaje = if (totalConfiguraciones > 0) (usuario1Total / totalConfiguraciones) * 100 else 0f
        val usuario2Porcentaje = if (totalConfiguraciones > 0) (usuario2Total / totalConfiguraciones) * 100 else 0f

        // Actualizar los TextViews
        usuario1Grafico.text = "$usuario1Nombre:\n(${String.format("%.2f", usuario1Porcentaje)}%)"
        usuario2Grafico.text = "$usuario2Nombre:\n(${String.format("%.2f", usuario2Porcentaje)}%)"
    }


    private fun listeners(email: String) {
        // Listener para el botón de regresar, que regresa a la actividad anterior
        btnRegresar?.setOnClickListener {
            val intent = Intent(this, ListaReporteReg::class.java).apply {
                putExtra("email", email)
            }
            startActivity(intent)
            finish()// Finaliza la actividad actual para evitar volver a ella con el botón de retroceso
        }

        // Listener para el botón de descarga, que muestra un mensaje de descarga
        btnDescarga?.setOnClickListener {
            val fileName = "ReporteTipo3_${System.currentTimeMillis()}.pdf"
            val pdfPath = generatePdfFromActivity(fileName)
            if (pdfPath != null) {
                Toast.makeText(this, "Reporte descargado: $pdfPath", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Error al descargar el reporte", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun generatePdfFromActivity(fileName: String): String? {
        return try {
            // Capturar la vista raíz del Activity
            val rootView = window.decorView.rootView
            rootView.isDrawingCacheEnabled = true
            val bitmap = Bitmap.createBitmap(rootView.drawingCache)
            rootView.isDrawingCacheEnabled = false

            // Crear el archivo PDF
            val pdfDocument = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(bitmap.width, bitmap.height, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            canvas.drawBitmap(bitmap, 0f, 0f, null)
            pdfDocument.finishPage(page)

            // Obtener la ruta para guardar en Descargas
            val backupPath = File(this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)

            // Guardar el PDF en el archivo
            val outputStream = FileOutputStream(backupPath)
            pdfDocument.writeTo(outputStream)
            pdfDocument.close()
            outputStream.close()

            // Devolver la ruta del archivo PDF
            backupPath.absolutePath
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }


    private fun sumarConfiguraciones(configuraciones: String?): Float {
        return configuraciones?.split(" - ", "\n")
            ?.fold(0f) { acc, item ->
                acc + (item.substringAfter(": ").substringBefore(" (").toFloatOrNull() ?: 0f)
            }
            ?: 0f
    }


    @Composable
    fun Pastel(data: List<Pair<String, Float>>) {
        val usedColors = mutableSetOf<Color>() // Mantén un registro de colores usados en la UI

        // Lista de colores directamente como objetos Color
        val colorList = listOf(
            Color(0xFF0EA982), // chat_green
            Color(0xFF2292D1), // cyan
            Color(0xFF098F33), // green
            Color(0xFFD3EFFF), // light_blue
            Color(0xFF3CE671), // light_green
            Color(0xFF505050), // gray
            Color(0xFFFF0000), // red
            Color(0xFFFF3030)  // light_red
        )

        // Si no hay datos, no renderizar el gráfico
        if (data.isEmpty()) return

        // Generar las porciones del gráfico
        val slices = data.map { (_, value) ->
            // Obtener un color único de la lista
            val color = generateUniqueComposeColor(colorList, usedColors)
            PieChartData.Slice(value = value, color = color)
        }

        // Crear el gráfico de pastel
        PieChart(
            pieChartData = PieChartData(slices = slices),
            sliceDrawer = SimpleSliceDrawer(sliceThickness = 100f)
        )
    }

    // Función para obtener un color único en Compose
    private fun generateUniqueComposeColor(
        colorList: List<Color>,
        usedColors: MutableSet<Color>
    ): Color {
        // Si todos los colores fueron usados, reiniciar
        if (usedColors.size == colorList.size) {
            usedColors.clear()
        }

        // Filtrar colores no utilizados
        val availableColors = colorList.filter { it !in usedColors }

        // Seleccionar un color no utilizado
        val selectedColor = availableColors.random()

        // Marcar como usado
        usedColors.add(selectedColor)

        return selectedColor
    }
}

