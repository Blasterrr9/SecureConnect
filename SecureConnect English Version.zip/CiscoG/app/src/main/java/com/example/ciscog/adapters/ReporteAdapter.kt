package com.example.ciscog.adapters

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.text.Editable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import com.example.ciscog.DataBaseLITE
import com.example.ciscog.R
import com.example.ciscog.ReportePlantilla1
import com.example.ciscog.ReportePlantilla2
import com.example.ciscog.ReportePlantilla3
import com.example.ciscog.ReportePlantilla4
import com.example.ciscog.ReportePlantilla5
import com.example.ciscog.ReportePlantilla6
import com.example.ciscog.models.Reporte

class ReporteAdapter(private val context: Activity, private var reporte: ArrayList<Reporte>): RecyclerView.Adapter<ReporteAdapter.reporteViewHolder>()  {

    private var db = DataBaseLITE(context)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): reporteViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.cardview_reportes, parent, false)
        return reporteViewHolder(view)
    }

    override fun getItemCount(): Int {

        return reporte.size
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: reporteViewHolder, position: Int) {
        val listaReporte = reporte[position]

        // Limpiar los campos antes de asignar nuevos valores
        holder.textViewAtributo3_Titulo.visibility = View.VISIBLE
        holder.textViewAtributo3_Valor.visibility = View.VISIBLE
        holder.textViewAtributo4_Titulo.visibility = View.VISIBLE
        holder.textViewAtributo4_Valor.visibility = View.VISIBLE

        holder.textViewAtributo1_Valor.textSize = 10f
        holder.textViewAtributo2_Valor.textSize = 12f
        holder.textViewAtributo3_Valor.textSize = 14f
        holder.textViewAtributo4_Valor.textSize = 12f

        //Asignamos los datos de la lista al Cardview
        holder.textViewTipo.text = listaReporte.tipo + " (ID: ${listaReporte.id})"
        holder.textViewAtributo1_Titulo.text = listaReporte.atributo1_titulo + ":"
        holder.textViewAtributo1_Valor.text = listaReporte.atributo1_valor
        holder.textViewAtributo2_Titulo.text = listaReporte.atributo2_titulo + ":"
        holder.textViewAtributo2_Valor.text = listaReporte.atributo2_valor
        holder.textViewFechaReporte.text = listaReporte.fecha

        if (listaReporte.atributo3_titulo != "/"){
            holder.textViewAtributo3_Titulo.text = listaReporte.atributo3_titulo + ":"
            holder.textViewAtributo3_Valor.text = listaReporte.atributo3_valor
            if (listaReporte.atributo4_titulo != "/"){
                holder.textViewAtributo4_Titulo.text = listaReporte.atributo4_titulo + ":"
                holder.textViewAtributo4_Valor.text = listaReporte.atributo4_valor
            } else {
                holder.textViewAtributo4_Titulo.visibility = View.GONE
                holder.textViewAtributo4_Valor.visibility = View.GONE
            }
        } else {
            holder.textViewAtributo3_Titulo.visibility = View.GONE
            holder.textViewAtributo3_Valor.visibility = View.GONE
            holder.textViewAtributo4_Titulo.visibility = View.GONE
            holder.textViewAtributo4_Valor.visibility = View.GONE

        }

        when (listaReporte.tipo) {
            "Report Type 1" -> {
                holder.textViewAtributo1_Valor.textSize = 14f
                holder.textViewAtributo2_Valor.textSize = 14f
                holder.textViewAtributo3_Valor.textSize = 14f
            }
            "Report Type 2" -> {
                holder.textViewAtributo1_Valor.textSize = 10f
                holder.textViewAtributo3_Valor.textSize = 12f
            }
            "Report Type 3" -> {
                holder.textViewAtributo1_Valor.textSize = 14f
                holder.textViewAtributo2_Valor.textSize = 9f
                holder.textViewAtributo3_Valor.textSize = 14f
                holder.textViewAtributo4_Valor.textSize = 9f
            }
            "Report Type 4" -> {
                holder.textViewAtributo1_Valor.textSize = 9f
                holder.textViewAtributo2_Valor.textSize = 10f
                holder.textViewAtributo3_Valor.textSize = 10f
            }
            "Report Type 5" -> {
                holder.textViewAtributo1_Valor.textSize = 10f
                holder.textViewAtributo2_Valor.textSize = 10f
                holder.textViewAtributo3_Valor.textSize = 10f
                holder.textViewAtributo4_Valor.textSize = 10f
            }
            "Report Type 6" -> {
                holder.textViewAtributo1_Valor.textSize = 12f
                holder.textViewAtributo2_Valor.textSize = 10f
            }
        }

        // Redirigir a Activity al hacer clic en el botón de visualizar
        holder.visMenu.setOnClickListener {
            when (listaReporte.tipo) {
                "Report Type 1" -> {
                    val intent = Intent(context, ReportePlantilla1::class.java).apply {
                        putExtra("atributo1_valor", listaReporte.atributo1_valor)
                        putExtra("atributo2_valor", listaReporte.atributo2_valor)
                        putExtra("atributo3_valor", listaReporte.atributo3_valor)
                    }
                    context.startActivity(intent)
                    context.finish()
                }
                "Report Type 2" -> {
                    val intent = Intent(context, ReportePlantilla2::class.java).apply {
                        putExtra("atributo1_valor", listaReporte.atributo1_valor)
                        putExtra("atributo2_valor", listaReporte.atributo2_valor)
                        putExtra("atributo3_valor", listaReporte.atributo3_valor)
                    }
                    context.startActivity(intent)
                    context.finish()
                }
                "Report Type 3" -> {
                    val intent = Intent(context, ReportePlantilla3::class.java).apply {
                        putExtra("atributo1_valor", listaReporte.atributo1_valor)
                        putExtra("atributo2_valor", listaReporte.atributo2_valor)
                        putExtra("atributo3_valor", listaReporte.atributo3_valor)
                        putExtra("atributo4_valor", listaReporte.atributo4_valor)
                    }
                    context.startActivity(intent)
                    context.finish()
                }
                "Report Type 4" -> {
                    val intent = Intent(context, ReportePlantilla4::class.java).apply {
                        putExtra("atributo1_valor", listaReporte.atributo1_valor)
                        putExtra("atributo2_valor", listaReporte.atributo2_valor)
                        putExtra("atributo3_valor", listaReporte.atributo3_valor)
                    }
                    context.startActivity(intent)
                    context.finish()
                }
                "Report Type 5" -> {
                    val intent = Intent(context, ReportePlantilla5::class.java).apply {
                        putExtra("atributo1_valor", listaReporte.atributo1_valor)
                        putExtra("atributo2_valor", listaReporte.atributo2_valor)
                        putExtra("atributo3_valor", listaReporte.atributo3_valor)
                        putExtra("atributo4_valor", listaReporte.atributo4_valor)
                    }
                    context.startActivity(intent)
                    context.finish()
                }
                "Report Type 6" -> {
                    val intent = Intent(context, ReportePlantilla6::class.java).apply {
                        putExtra("atributo1_valor", listaReporte.atributo1_valor)
                        putExtra("atributo2_valor", listaReporte.atributo2_valor)
                    }
                    context.startActivity(intent)
                    context.finish()
                }
            }
        }

    }


    //Lista de elemntos encontrados con el SearchView
    @SuppressLint("NotifyDataSetChanged")
    fun setFilteredList(mList: ArrayList<Reporte>){

        this.reporte = mList
        notifyDataSetChanged()
    }



    class reporteViewHolder(view: View): RecyclerView.ViewHolder(view){
        val textViewTipo: TextView = view.findViewById(R.id.textview_tipo_reporte)
        val textViewAtributo1_Titulo: TextView = view.findViewById(R.id.textview_atributo_1_titulo)
        val textViewAtributo1_Valor: TextView = view.findViewById(R.id.textview_atributo_1_valor)
        val textViewAtributo2_Titulo: TextView = view.findViewById(R.id.textview_atributo_2_titulo)
        val textViewAtributo2_Valor: TextView = view.findViewById(R.id.textview_atributo_2_valor)
        val textViewAtributo3_Titulo: TextView = view.findViewById(R.id.textview_atributo_3_titulo)
        val textViewAtributo3_Valor: TextView = view.findViewById(R.id.textview_atributo_3_valor)
        val textViewAtributo4_Titulo: TextView = view.findViewById(R.id.textview_atributo_4_titulo)
        val textViewAtributo4_Valor: TextView = view.findViewById(R.id.textview_atributo_4_valor)
        val textViewFechaReporte: TextView = view.findViewById(R.id.textview_fecha_reporte_valor)

        val visMenu: ImageButton = view.findViewById(R.id.visualizar_btn)
    }
}